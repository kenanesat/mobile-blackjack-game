package com.example.blackjack

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                BlackjackScreen()
            }
        }
    }
}

enum class Suit(val symbol: String) {
    SPADES("♠"),
    HEARTS("♥"),
    DIAMONDS("♦"),
    CLUBS("♣")
}

data class Card(val rank: String, val suit: Suit) {
    override fun toString(): String = "$rank${suit.symbol}"
}

class Deck {
    private val cards = buildList {
        val ranks = listOf("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")
        for (s in Suit.entries) {
            for (r in ranks) {
                add(Card(r, s))
            }
        }
    }.shuffled(Random.Default).toMutableList()

    fun draw(): Card {
        if (cards.isEmpty()) error("Deck empty")
        return cards.removeAt(cards.lastIndex)
    }
}

fun handValue(hand: List<Card>): Int {
    var total = 0
    var aces = 0

    for (c in hand) {
        total += when (c.rank) {
            "A" -> {
                aces++
                11
            }
            "K", "Q", "J" -> 10
            else -> c.rank.toInt()
        }
    }

    while (total > 21 && aces > 0) {
        total -= 10
        aces--
    }

    return total
}

fun isBlackjack(hand: List<Card>) = hand.size == 2 && handValue(hand) == 21

enum class State { READY, PLAYER_TURN, FINISHED }

private val ScreenBg = Color.Black
private val PanelColor = Color(0xFF151922)
private val DealGreen = Color(0xFF00A86B)
private val HitYellow = Color(0xFFFACC15)
private val StandRed = Color(0xFFEF4444)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlackjackScreen() {
    var deck by remember { mutableStateOf(Deck()) }
    var player by remember { mutableStateOf<List<Card>>(emptyList()) }
    var dealer by remember { mutableStateOf<List<Card>>(emptyList()) }
    var state by remember { mutableStateOf(State.READY) }
    var message by remember { mutableStateOf("Press Deal") }

    val scope = rememberCoroutineScope()

    fun safeDraw(): Card =
        runCatching { deck.draw() }.getOrElse {
            deck = Deck()
            deck.draw()
        }

    fun newRound() {
        player = emptyList()
        dealer = emptyList()
        state = State.READY
        message = "Press Deal"
    }

    fun dealerPlayAndFinish() {
        while (handValue(dealer) < 17) {
            dealer = dealer + safeDraw()
        }

        val p = handValue(player)
        val d = handValue(dealer)

        state = State.FINISHED
        message = when {
            d > 21 -> "Dealer Lose! You Win 🎉"
            p > d -> "You Win 🎉"
            d > p -> "Dealer Wins ❌"
            else -> "Push 🤝"
        }
    }

    fun deal() {
        player = listOf(safeDraw(), safeDraw())
        dealer = listOf(safeDraw(), safeDraw())

        when {
            isBlackjack(player) && isBlackjack(dealer) -> {
                state = State.FINISHED
                message = "Both Blackjack! Push 🤝"
            }
            isBlackjack(player) -> {
                state = State.FINISHED
                message = "Blackjack! You Win 🎉"
            }
            isBlackjack(dealer) -> {
                state = State.FINISHED
                message = "Dealer Win. You Lose! ❌"
            }
            else -> {
                state = State.PLAYER_TURN
                message = "Hit or Stand?"
            }
        }
    }

    fun hit() {
        if (state != State.PLAYER_TURN) return

        player = player + safeDraw()
        val pv = handValue(player)

        when {
            pv > 21 -> {
                state = State.FINISHED
                message = "Bust! You lose ❌"
            }
            pv == 21 -> {
                message = "21! Dealer Plays..."
                scope.launch {
                    delay(1000)
                    dealerPlayAndFinish()
                }
            }
            else -> message = "Hit or Stand?"
        }
    }

    fun stand() {
        if (state != State.PLAYER_TURN) return
        message = "Dealer Plays..."
        scope.launch {
            delay(1000)
            dealerPlayAndFinish()
        }
    }

    val dealerHidden = (state == State.PLAYER_TURN && dealer.size >= 2)
    val dealerCardsText =
        if (dealerHidden) "${dealer.first()}  [??]" else dealer.joinToString("  ")

    val dealerValueText =
        if (dealerHidden) "?" else handValue(dealer).toString()

    val playerCardsText = player.joinToString("  ").ifBlank { "—" }
    val playerValueText = handValue(player).toString()

    val canDeal = (state == State.READY || state == State.FINISHED)
    val canPlay = (state == State.PLAYER_TURN)

    val screenH = LocalConfiguration.current.screenHeightDp
    val buttonsAreaH = (screenH * 0.33f).dp
    val spacing = 14.dp

    Scaffold(
        containerColor = ScreenBg,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "BLACKJACK",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = PanelColor
                )
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CardBoxBig("Dealer", dealerCardsText, dealerValueText)
            CardBoxBig("You", playerCardsText, playerValueText)

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PanelColor)
                ) {
                    Text(
                        text = message,
                        modifier = Modifier.padding(horizontal = 28.dp, vertical = 18.dp),
                        color = Color.White,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(buttonsAreaH),
                verticalArrangement = Arrangement.spacedBy(spacing),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BigPillButton("DEAL", DealGreen, canDeal, 72.dp) { deal() }
                BigPillButton("HIT", HitYellow, canPlay, 72.dp) { hit() }
                BigPillButton("STAND", StandRed, canPlay, 72.dp) { stand() }
            }

            OutlinedButton(
                onClick = { newRound() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color(0xFF7C3AED),
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = "New Round",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun CardBoxBig(title: String, cards: String, valueText: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = PanelColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )

                Text(
                    text = "Value: $valueText",
                    color = Color(0xFFD0D6DE),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }

            Text(
                text = if (cards.isBlank()) "—" else cards,
                color = Color.White,
                fontSize = 20.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun BigPillButton(
    text: String,
    color: Color,
    enabled: Boolean,
    height: Dp,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth(0.9f)
            .height(height),
        shape = RoundedCornerShape(999.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            contentColor = Color.Black,
            disabledContainerColor = color.copy(alpha = 0.35f),
            disabledContentColor = Color(0xFFB0B7BE)
        )
    ) {
        Text(
            text = text,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black
        )
    }
}
